let isLoggedIn = false;

function login() {
  const user = prompt("ادخل اسم المستخدم:");
  const pass = prompt("ادخل كلمة المرور:");
  if (user && pass) {
    isLoggedIn = true;
    document.getElementById("output").innerText = "✅ مرحباً بك يا " + user + "!";
    document.getElementById("username").innerText = "👤 " + user;
    document.getElementById("logout-btn").style.display = "inline-block";
    document.querySelectorAll(".protected").forEach(btn => btn.disabled = false);
  } else {
    alert("يرجى إدخال كل المعلومات.");
  }
}

function logout() {
  isLoggedIn = false;
  document.getElementById("username").innerText = "غير مسجل";
  document.getElementById("logout-btn").style.display = "none";
  document.getElementById("output").innerText = "";
  document.querySelectorAll(".protected").forEach(btn => btn.disabled = true);
}

function showResults() {
  if (!isLoggedIn) {
    alert("يجب تسجيل الدخول أولاً.");
    return;
  }
  const name = prompt("ادخل اسمك الثلاثي:");
  const province = prompt("ادخل محافظتك:");
  if (name.trim() && province.trim()) {
    window.open("https://iraqedu.net/نتائج-الثالث-المتوسط-2025-الدور-الاول/", "_blank");
  } else {
    alert("❗ يرجى إدخال كل المعلومات.");
  }
}

function openTelegram() {
  if (!isLoggedIn) {
    alert("يجب تسجيل الدخول أولاً.");
    return;
  }
  window.open("https://t.me/eieieieeeekdkdk", "_blank");
}